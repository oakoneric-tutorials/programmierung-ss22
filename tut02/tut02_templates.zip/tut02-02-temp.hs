-- Aufgabe 2

-- (a) Präfix-Test
isPrefix :: String -> String -> Bool


-- (b) Vorkommen zählen
countPattern :: String -> String -> Int
