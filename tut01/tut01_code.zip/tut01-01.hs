{- 
mehrzeiliger
Kommentar
-}

sum3 :: Int -> Int -> Int -> Int
sum3 x y z = x + y + z  -- einzeiliger Kommentar